package WenBao.service.impl;

import WenBao.entity.Book;
import WenBao.entity.Borrow;
import WenBao.repository.BookRepository;
import WenBao.repository.BorrowRepository;
import WenBao.repository.impl.BookRepositoryImpl;
import WenBao.repository.impl.BorrowRepositoryImpl;
import WenBao.service.BookService;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class BookServiceImpl implements BookService {

    private BookRepository bookRepository = new BookRepositoryImpl();
    private BorrowRepository borrowRepository = new BorrowRepositoryImpl();
    private final int limit = 10;

    @Override
    public List<Book> findAll(int page) {
        int index = (page - 1) * limit;
        return bookRepository.findAll(index, limit);
    }

    @Override
    public int getPages() {
        int pages = bookRepository.getPages();
        int conut = (int) Math.ceil((double) pages / limit);
        return conut;
    }

    @Override
    public void addBorrow(Integer bookid, Integer readerid) {
        //借书时间
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String borrowTime = simpleDateFormat.format(new Date());
        //还书时间=借书时间+14天
        Calendar calendar = Calendar.getInstance();
        int dates = calendar.get(Calendar.DAY_OF_YEAR) + 14;
        calendar.set(Calendar.DAY_OF_YEAR, dates);
        String returnTime = simpleDateFormat.format(calendar.getTime());

        borrowRepository.insert(bookid, readerid, borrowTime, returnTime, null, 0);
        return;
    }

    @Override
    public List<Borrow> findAllBorrowByReaderId(Integer id, Integer page) {
        //将page换成为index limit
        int index = (page - 1) * limit;
        return borrowRepository.findAllByReaderId(id, index, limit);
    }

    @Override
    public int getBorrowPages(Integer id) {
        int pages = borrowRepository.getPages(id);
        int conut = (int) Math.ceil((double) pages / limit);
        return conut;
    }

    @Override
    public List<Borrow> findAllBorrowByState(Integer state, Integer page) {
        int index = (page - 1) * limit;
        return borrowRepository.findAllByState(state, index, limit);
    }

    @Override
    public int getBorrowPagesByState(Integer state) {
        int pages = borrowRepository.getBorrowPages(state);
        int conut = (int) Math.ceil((double) pages / limit);
        return conut;
    }

    @Override
    public void HandleBorrow(Integer borrowId, Integer state, Integer adminId) {
        borrowRepository.handleBorrow(borrowId, state, adminId);
        return;
    }
}
