package WenBao.service;

import WenBao.entity.Reader;

public interface LoginService {
    public Object login(String username, String password, String type);
}
