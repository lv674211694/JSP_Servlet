package WenBao.repository;

import WenBao.entity.Reader;

public interface ReaderRepository {
    public Reader login(String username, String password);
}
