package WenBao.repository;

import WenBao.entity.Admin;

public interface AdminRepository {
    public Admin login(String username, String password);
}
