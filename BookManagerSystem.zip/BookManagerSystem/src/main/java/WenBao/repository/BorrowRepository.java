package WenBao.repository;

import WenBao.entity.Borrow;

import java.util.List;

public interface BorrowRepository {
    public void insert(Integer bookid, Integer readerid, String borrowTime, String returnTime, Integer adminid, Integer state);

    public List<Borrow> findAllByReaderId(Integer readerId, Integer index, Integer limit);

    public int getPages(Integer readerId);

    public List<Borrow> findAllByState(Integer state, Integer index, Integer limit);

    public int getBorrowPages(Integer state);

    public void handleBorrow(Integer borrowId, Integer state, Integer adminId);
}
