package WenBao.repository.impl;

import WenBao.entity.Book;
import WenBao.entity.Borrow;
import WenBao.entity.Reader;
import WenBao.repository.BorrowRepository;
import com.mysql.cj.protocol.ResultsetRow;
import utils.JDBCTools;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BorrowRepositoryImpl implements BorrowRepository {
    @Override
    public void insert(Integer bookid, Integer readerid, String borrowTime, String returnTime, Integer adminid, Integer state) {
        Connection connection = JDBCTools.getConnection();
        String sql = "insert into borrow(bookid,readerid,borrowtime,returntime,state) VALUES (?,?,?,?,0)";
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(sql);
            statement.setInt(1, bookid);
            statement.setInt(2, readerid);
            statement.setString(3, borrowTime);
            statement.setString(4, returnTime);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCTools.release(connection, statement, null);
        }
    }

    @Override
    public List<Borrow> findAllByReaderId(Integer readerId, Integer index, Integer limit) {
        Connection connection = JDBCTools.getConnection();
        String sql = "select br.id, b.name,b.author,b.publish,br.borrowtime,br.returntime,r.name,r.tel,r.cardid,br.state from borrow br,reader r,book b where readerid = ? and b.id = br.bookid and r.id = br.readerid limit ?,?";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Borrow> list = new ArrayList<>();
        try {
            statement = connection.prepareStatement(sql);
            statement.setInt(1, readerId);
            statement.setInt(2, index);
            statement.setInt(3, limit);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                list.add(new Borrow(
                        resultSet.getInt(1),
                        new Book(resultSet.getString(2), resultSet.getString(3), resultSet.getString(4)),
                        new Reader(resultSet.getString(7), resultSet.getString(8), resultSet.getString(9)),
                        resultSet.getString(5),
                        resultSet.getString(6),
                        resultSet.getInt(10)
                ));
            }
            int i = 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCTools.release(connection, statement, resultSet);
        }
        return list;
    }

    @Override
    public int getPages(Integer readerId) {
        Connection connection = JDBCTools.getConnection();
        String sql = "select count(*) from borrow br,reader r,book b where readerid = ? and b.id = br.bookid and r.id = br.readerid";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        int Pages = 0;
        try {
            statement = connection.prepareStatement(sql);
            statement.setInt(1, readerId);
            resultSet = statement.executeQuery();
            if (resultSet.next())
                Pages = resultSet.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCTools.release(connection, statement, resultSet);
        }
        return Pages;
    }

    @Override
    public List<Borrow> findAllByState(Integer state, Integer index, Integer limit) {
        Connection connection = JDBCTools.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String sql = "select br.id, b.name,b.author,b.publish,br.borrowtime,br.returntime,r.name,r.tel,r.cardid,br.state from borrow br,reader r,book b where state = ? and b.id = br.bookid and r.id = br.readerid limit ?,?";
        List<Borrow> list = new ArrayList<>();
        try {
            statement = connection.prepareStatement(sql);
            statement.setInt(1, state);
            statement.setInt(2, index);
            statement.setInt(3, limit);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                list.add(new Borrow(
                        resultSet.getInt(1),
                        new Book(resultSet.getString(2), resultSet.getString(3), resultSet.getString(4)),
                        new Reader(resultSet.getString(7), resultSet.getString(8), resultSet.getString(9)),
                        resultSet.getString(5),
                        resultSet.getString(6),
                        resultSet.getInt(10)
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCTools.release(connection, statement, resultSet);
        }
        return list;
    }

    @Override
    public int getBorrowPages(Integer state) {
        Connection connection = JDBCTools.getConnection();
        String sql = "select count(*) from borrow br,reader r,book b where state = ? and b.id = br.bookid and r.id = br.readerid";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        int Pages = 0;
        try {
            statement = connection.prepareStatement(sql);
            statement.setInt(1, state);
            resultSet = statement.executeQuery();
            if (resultSet.next())
                Pages = resultSet.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCTools.release(connection, statement, resultSet);
        }
        return Pages;
    }

    @Override
    public void handleBorrow(Integer borrowId, Integer state, Integer adminId) {
        Connection connection = JDBCTools.getConnection();
        String sql = "update borrow\n" +
                "set state  = ?,\n" +
                "    adminid= ?\n" +
                "where id = ?;";
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(sql);
            statement.setInt(1, state);
            statement.setInt(2, adminId);
            statement.setInt(3, borrowId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCTools.release(connection, statement, null);
        }

        return;
    }
}
