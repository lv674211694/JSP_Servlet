package WenBao.controller;

import WenBao.entity.Admin;
import WenBao.entity.Book;
import WenBao.entity.Borrow;
import WenBao.entity.Reader;
import WenBao.service.BookService;
import WenBao.service.LoginService;
import WenBao.service.impl.BookServiceImpl;
import WenBao.service.impl.LoginServiceImpl;
import com.mysql.cj.Session;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/login")
public class loginServlet extends HttpServlet {

    private LoginService loginService = new LoginServiceImpl();

    /**
     * 处理登录的业务逻辑
     * 主要功能: 实现读者,管理员页面的跳转;
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取表单中的账号密码
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        //确定读者 或 管理员
        String type = req.getParameter("type");
        Object object = loginService.login(username, password, type);
        if (object != null) {
            HttpSession httpSession = req.getSession();
            switch (type) {
                case "reader":
                    Reader reader = (Reader) object;
                    httpSession.setAttribute("reader", reader);
                    //跳转读者页面
                    resp.sendRedirect("/book?page=1");
                    break;
                case "admin":
                    Admin admin = (Admin) object;
                    httpSession.setAttribute("admin", admin);
                    //跳转管理员页面
                    resp.sendRedirect("/admin?method=findAllBorrow&page=1");
                    break;
            }
        } else {
            //如果表单信息丢失,则跳回登录页面
            resp.sendRedirect("login.jsp");
        }
    }
}
