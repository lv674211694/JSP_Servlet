package WenBao.controller;

import WenBao.entity.Admin;
import WenBao.entity.Borrow;
import WenBao.service.BookService;
import WenBao.service.LoginService;
import WenBao.service.impl.BookServiceImpl;
import WenBao.service.impl.LoginServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin")
public class AdminServlet extends HttpServlet {

    private BookService bookService = new BookServiceImpl();

    /**
     * 本类为处理管理员业务逻辑
     * 主要功能:
     *          1)查询所有待批借书请求,并给予同意/拒绝
     *          2)查询所有待批还书请求,并确认归还
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("method");
        if (method == null) {
            method = "findAllBorrow";
        }
        HttpSession session = req.getSession();
        Admin admin = (Admin) session.getAttribute("admin");
        switch (method) {
            case "findAllBorrow":
                String pageStr = req.getParameter("page");
                Integer page = Integer.parseInt(pageStr);
                List<Borrow> list = bookService.findAllBorrowByState(0, page);
                req.setAttribute("list", list);
                req.setAttribute("dataPrePage", 10);
                req.setAttribute("currentPage", page);
                req.setAttribute("pages", bookService.getBorrowPagesByState(0));
                req.getRequestDispatcher("admin.jsp").forward(req, resp);
                break;
            case "handle":
                String idStr = req.getParameter("id");
                String stateStr = req.getParameter("state");
                Integer id = Integer.parseInt(idStr);
                Integer state = Integer.parseInt(stateStr);
                bookService.HandleBorrow(id, state, admin.getId());
                if (state == 3)
                    resp.sendRedirect("/admin?method=getBorrowed&page=1");
                else
                        resp.sendRedirect("/admin?page=1");
                break;
            case "getBorrowed":
                pageStr = req.getParameter("page");
                page = Integer.parseInt(pageStr);
                list = bookService.findAllBorrowByState(1, page);
                req.setAttribute("list", list);
                req.setAttribute("dataPrePage", 10);
                req.setAttribute("currentPage", page);
                req.setAttribute("pages", bookService.getBorrowPagesByState(1));
                req.getRequestDispatcher("return.jsp").forward(req, resp);
                break;
        }

    }
}
