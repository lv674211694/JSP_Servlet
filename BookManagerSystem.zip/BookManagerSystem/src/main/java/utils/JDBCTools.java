package utils;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import javax.sql.DataSource;
import java.sql.*;

public class JDBCTools {
    private static DataSource dataSource;

    static {
        dataSource = new ComboPooledDataSource("testc3p0");
    }

    /**
     * 本类功能:
     * 1)连接数据库连接池,并获取一个连接
     * 2)释放连接,并归还给数据库连接池
     * @return
     */
    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = dataSource.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;

    }
    public static void release(Connection connection, PreparedStatement statement, ResultSet resultSet) {
        try {
            if (connection != null) connection.close();
            if (statement != null) statement.close();
            if (resultSet != null) resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 测试数据库连接池 连接成功
     * 结果如下:
     * com.mchange.v2.c3p0.impl.NewProxyConnection@7d417077 [wrapping: com.mysql.cj.jdbc.ConnectionImpl@7dc36524]
     */
/*    public static void main(String[] args) {
        System.out.println(JDBCTools.getConnection());
    }*/
}
